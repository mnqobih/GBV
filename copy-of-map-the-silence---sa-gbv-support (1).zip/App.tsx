
import React, { useState, useEffect } from 'react';
import { AppView } from './types';
import { generateIntroAudio } from './services/geminiService';
import { Dashboard } from './components/Dashboard';
import { SurveyForm } from './components/SurveyForm';
import { PerpetratorSurvey } from './components/PerpetratorSurvey';
import { AIChat } from './components/AIChat';
import { LiveVoiceAgent } from './components/LiveVoiceAgent';
import { Logo } from './components/Logo'; // Import Logo
import { seedInitialData, clearSubmissions } from './services/storageService';

const SurveySelectionModal = ({ onSelect, onClose }: { onSelect: (type: 'survivor' | 'perpetrator') => void, onClose: () => void }) => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
        <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-slate-900 mb-4 text-center">What would you like to do?</h3>
            
            <button 
                onClick={() => onSelect('survivor')}
                className="w-full mb-4 p-4 rounded-xl border-2 border-brand-100 bg-brand-50 hover:bg-brand-100 hover:border-brand-300 transition-all text-left flex items-center gap-4 group"
            >
                <div className="w-12 h-12 bg-brand-500 text-white rounded-full flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform">📢</div>
                <div>
                    <div className="font-bold text-brand-900">Share a Story</div>
                    <div className="text-xs text-brand-700">I am a survivor or I witnessed an incident.</div>
                </div>
            </button>

            <button 
                onClick={() => onSelect('perpetrator')}
                className="w-full p-4 rounded-xl border-2 border-slate-100 bg-white hover:bg-slate-50 hover:border-slate-300 transition-all text-left flex items-center gap-4 group"
            >
                <div className="w-12 h-12 bg-slate-700 text-white rounded-full flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform">🤔</div>
                <div>
                    <div className="font-bold text-slate-900">Self-Reflection</div>
                    <div className="text-xs text-slate-500">I may have caused harm and want to reflect.</div>
                </div>
            </button>

            <button onClick={onClose} className="mt-6 w-full text-center text-slate-400 text-sm hover:text-slate-600">Cancel</button>
        </div>
    </div>
);

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);
  const [showSurveyModal, setShowSurveyModal] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioSource, setAudioSource] = useState<AudioBufferSourceNode | null>(null);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [chatKey, setChatKey] = useState(0); 
  const [showVoiceAgent, setShowVoiceAgent] = useState(false);

  useEffect(() => { seedInitialData(); }, []);

  const getAudioContext = () => {
    if (!audioContext) {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      setAudioContext(ctx);
      return ctx;
    }
    return audioContext;
  };

  const handlePanic = () => window.location.replace("https://www.google.com");
  const handleClearChat = () => setChatKey(prev => prev + 1);
  const handleClearFootprint = () => {
      if (confirm("Safety Check: This will delete all local data (chats, submissions) on this device. Continue?")) {
          clearSubmissions();
          handleClearChat();
          alert("Device footprint cleared.");
          window.location.reload();
      }
  };

  const pcmToAudioBuffer = (buffer: ArrayBuffer, ctx: AudioContext, sampleRate: number = 24000) => {
    const dataInt16 = new Int16Array(buffer);
    const frameCount = dataInt16.length; 
    const audioBuffer = ctx.createBuffer(1, frameCount, sampleRate); 
    const channelData = audioBuffer.getChannelData(0);
    for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i] / 32768.0;
    return audioBuffer;
  };

  const handlePlayAudio = async (lang: 'English' | 'Zulu' | 'Afrikaans') => {
    if (isPlayingAudio && audioSource) {
      audioSource.stop();
      setIsPlayingAudio(false);
      return;
    }
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') await ctx.resume();
    const base64Audio = await generateIntroAudio(lang);
    if (!base64Audio) return;
    const binaryString = atob(base64Audio);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
    try {
      const audioBuffer = pcmToAudioBuffer(bytes.buffer, ctx, 24000);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.start(0);
      setAudioSource(source);
      setIsPlayingAudio(true);
      source.onended = () => setIsPlayingAudio(false);
    } catch (e) { console.error(e); setIsPlayingAudio(false); }
  };

  const handleSurveySelect = (type: 'survivor' | 'perpetrator') => {
      setShowSurveyModal(false);
      if (type === 'survivor') setCurrentView(AppView.SURVEY);
      else setCurrentView(AppView.PERPETRATOR_SURVEY);
  };

  const Waveform = () => (
     <div className="flex gap-0.5 items-end h-4 ml-2">
         <div className="bar w-0.5 bg-brand-600 animate-[sound_0.6s_ease-in-out_infinite] h-2"></div>
         <div className="bar w-0.5 bg-brand-600 animate-[sound_0.8s_ease-in-out_infinite_0.1s] h-3"></div>
         <div className="bar w-0.5 bg-brand-600 animate-[sound_0.5s_ease-in-out_infinite_0.2s] h-1.5"></div>
         <div className="bar w-0.5 bg-brand-600 animate-[sound_0.7s_ease-in-out_infinite_0.3s] h-2.5"></div>
     </div>
  );

  const NavButton = ({ view, label, icon, onClick }: { view?: AppView, label: string, icon: string, onClick?: () => void }) => (
    <button 
      onClick={onClick ? onClick : () => setCurrentView(view!)} 
      className={`flex flex-col items-center justify-center w-full py-2 transition-colors ${currentView === view ? 'text-brand-600' : 'text-slate-400 hover:text-slate-600'}`}
    >
      <span className="text-xl mb-0.5">{icon}</span>
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen flex flex-col font-sans bg-slate-50 text-slate-900 pb-20 md:pb-0">
      
      {showVoiceAgent && <LiveVoiceAgent onClose={() => setShowVoiceAgent(false)} />}
      {showSurveyModal && <SurveySelectionModal onSelect={handleSurveySelect} onClose={() => setShowSurveyModal(false)} />}

      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center cursor-pointer" onClick={() => setCurrentView(AppView.LANDING)}>
              <Logo className="w-10 h-10" showText={true} />
            </div>
            <nav className="hidden md:flex space-x-8">
              <button onClick={() => setShowSurveyModal(true)} className={`${currentView === AppView.SURVEY || currentView === AppView.PERPETRATOR_SURVEY ? 'text-brand-600 bg-brand-50' : 'text-slate-500'} px-3 py-1 rounded-md hover:text-brand-600 font-medium transition-colors`}>Report / Reflect</button>
              <button onClick={() => setCurrentView(AppView.DASHBOARD)} className={`${currentView === AppView.DASHBOARD ? 'text-brand-600 bg-brand-50' : 'text-slate-500'} px-3 py-1 rounded-md hover:text-brand-600 font-medium transition-colors`}>Data & Stats</button>
              <button onClick={() => setCurrentView(AppView.CHAT)} className={`${currentView === AppView.CHAT ? 'text-brand-600 bg-brand-50' : 'text-slate-500'} px-3 py-1 rounded-md hover:text-brand-600 font-medium transition-colors`}>Chat Support</button>
            </nav>
            <div className="flex gap-2">
               <button onClick={() => setShowVoiceAgent(true)} className="hidden md:flex bg-slate-800 hover:bg-slate-900 text-white px-3 py-2 rounded-lg text-sm font-semibold shadow-md items-center gap-2 transition-transform active:scale-95"><span>📞 AI Call</span></button>
               <button onClick={handlePanic} className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-md transition-all active:scale-95 flex items-center gap-2 border border-red-800 ring-2 ring-red-100"><span>EXIT</span><span className="text-xs opacity-80 hidden sm:inline">(Esc)</span></button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-grow pt-8 pb-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {currentView === AppView.LANDING && (
          <div className="space-y-12 animate-fade-in">
            <div className="text-center max-w-3xl mx-auto mt-4 md:mt-8">
              <div className="flex justify-center mb-6">
                 <Logo className="w-24 h-24 md:w-32 md:h-32" />
              </div>
              <h1 className="text-3xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight leading-tight">Map the silence. <br/><span className="text-brand-600">Amplify the survivors.</span></h1>
              <p className="text-base md:text-lg text-slate-600 mb-8 leading-relaxed">A safe, anonymous platform to report Gender-Based Violence in South Africa, access support, and help us improve services through data.</p>
              <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
                <button onClick={() => setShowSurveyModal(true)} className="bg-brand-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-brand-700 shadow-xl shadow-brand-200/50 transition-all transform hover:-translate-y-1">Share your story</button>
                 <button onClick={() => document.getElementById('hotlines')?.scrollIntoView({behavior:'smooth'})} className="bg-white text-slate-700 border border-slate-300 px-6 py-4 rounded-xl text-lg font-semibold hover:bg-slate-50 transition-colors">Get help now</button>
              </div>
              <div className="flex flex-wrap gap-3 justify-center mb-8">
                  {['English', 'Zulu', 'Afrikaans'].map(lang => (
                      <button key={lang} onClick={() => handlePlayAudio(lang as any)} className={`relative px-4 py-2 md:px-6 md:py-3 rounded-full font-medium text-xs md:text-sm transition-all duration-200 active:scale-95 flex items-center gap-2 overflow-hidden ${isPlayingAudio ? 'bg-brand-50 text-brand-700 border border-brand-200 shadow-inner' : 'bg-white text-slate-600 border border-slate-200 hover:border-brand-300 hover:shadow-md'}`}>
                         <span className="text-lg">{isPlayingAudio ? '🔊' : '🔈'}</span> {lang} {isPlayingAudio && <Waveform />}
                      </button>
                  ))}
                </div>
            </div>
            <div id="hotlines" className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 border-l-4 border-l-brand-500 hover:shadow-md transition-shadow">
                <h3 className="font-bold text-lg mb-2 text-slate-900">GBV Command Centre</h3>
                <p className="text-3xl font-bold text-brand-600 mb-1 tracking-tight">0800 428 428</p>
                <p className="text-sm text-slate-500">24/7 National Support & Counselling (USSD available)</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 border-l-4 border-l-slate-800 hover:shadow-md transition-shadow">
                <h3 className="font-bold text-lg mb-2 text-slate-900">SAPS Emergency</h3>
                <p className="text-3xl font-bold text-slate-800 mb-1 tracking-tight">10111</p>
                <p className="text-sm text-slate-500">Immediate Police Response</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 border-l-4 border-l-teal-500 hover:shadow-md transition-shadow">
                <h3 className="font-bold text-lg mb-2 text-slate-900">TEARS Foundation</h3>
                <p className="text-3xl font-bold text-teal-600 mb-1 tracking-tight">08000 83277</p>
                <p className="text-sm text-slate-500">Help, Shelter & Support Info</p>
              </div>
            </div>
            <div className="bg-slate-100 p-8 rounded-2xl text-sm text-slate-700 max-w-4xl mx-auto border border-slate-200 text-center">
              <p className="font-bold mb-2 text-base text-slate-900">Your safety & privacy first.</p>
              <p className="leading-relaxed mb-4">This survey is anonymous unless you choose otherwise. We do not store identifying information. All submissions are encrypted.</p>
              <p className="font-medium text-brand-700">If you are in immediate danger, call the GBV Command Centre 0800 428 428 or SAPS emergency 10111.</p>
            </div>
          </div>
        )}

        {currentView === AppView.SURVEY && <SurveyForm onComplete={() => setCurrentView(AppView.DASHBOARD)} />}
        {currentView === AppView.PERPETRATOR_SURVEY && <PerpetratorSurvey onComplete={() => setCurrentView(AppView.DASHBOARD)} onExit={() => setCurrentView(AppView.LANDING)} />}
        {currentView === AppView.DASHBOARD && <Dashboard />}
        {currentView === AppView.CHAT && <AIChat key={chatKey} onClear={handleClearChat} />}
      </main>

      <footer className="bg-white border-t border-slate-200 mt-auto mb-16 md:mb-0">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                    <h4 className="font-bold text-brand-900 flex items-center gap-2">Context <span className="text-xs bg-slate-100 px-2 py-0.5 rounded text-slate-500 font-normal">HSRC & CGE 2024 Reports</span></h4>
                    <p className="text-sm text-slate-500 mt-2 leading-relaxed">Based on the CGE's "Towards a GBV Index" (2024) and HSRC National Survey. We advocate for recognising all forms of violence including economic, spiritual, and technology-facilitated abuse.</p>
                </div>
                <div className="flex flex-col md:items-end gap-4 text-sm text-slate-600">
                    <div className="flex flex-wrap gap-4">
                        <p className="bg-slate-50 px-3 py-1 rounded border border-slate-100"><strong>SAPS:</strong> 10111</p>
                        <p className="bg-slate-50 px-3 py-1 rounded border border-slate-100"><strong>GBV Command:</strong> 0800 428 428</p>
                    </div>
                    <button onClick={handleClearFootprint} className="text-slate-400 hover:text-red-600 text-xs underline transition-colors">Safety: Clear all local data from this device</button>
                </div>
            </div>
            <div className="mt-8 pt-8 border-t border-slate-100 text-center text-xs text-slate-400">&copy; 2024 Map the Silence Initiative. This is a secure, anonymous demo application.</div>
        </div>
      </footer>

      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-50 pb-safe">
        <div className="flex justify-around items-center h-16">
          <NavButton view={AppView.LANDING} label="Home" icon="🏠" />
          <NavButton label="Report" icon="📝" onClick={() => setShowSurveyModal(true)} />
          <NavButton view={AppView.DASHBOARD} label="Data" icon="📊" />
          <NavButton view={AppView.CHAT} label="Chat" icon="💬" />
        </div>
      </div>

      <div className="md:hidden fixed bottom-20 right-4 z-40">
        <button onClick={() => setShowVoiceAgent(true)} className="flex items-center justify-center w-14 h-14 bg-slate-800 text-white rounded-full shadow-lg shadow-slate-900/50 animate-bounce-slow border-2 border-white/20"><span className="text-2xl">🎙️</span></button>
      </div>
    </div>
  );
};

export default App;
