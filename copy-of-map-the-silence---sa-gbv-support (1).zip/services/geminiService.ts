
import { GoogleGenAI, Modality, Type } from "@google/genai";

// Initialize Gemini Client
export const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

// 1. Text-to-Speech for Landing Page
export const generateIntroAudio = async (language: 'English' | 'Zulu' | 'Afrikaans'): Promise<string | null> => {
  try {
    let textToSay = "";
    
    // Scripts based on requirements
    if (language === 'English') {
      textToSay = "Welcome. This site is a safe place to share if you or someone you know has experienced gender-based violence. Your answers are anonymous and protected. By sharing your experience you help us map where help is most needed in South Africa and push for better services. If you are in immediate danger, call the GBV Command Centre on 0800 428 428 or the police on 10111 right now. If you need a counsellor, dial TEARS at 08000 83277. You are not alone — help is available.";
    } else if (language === 'Zulu') {
      textToSay = "Sawubona. Le ndawo iphephile ukwabelana uma wena noma othile amaziyo ehlangabezane nodlame olubhekiswe kobulili. Izimpendulo zakho azaziwa futhi zivikelekile. Uma usengozini, fonela i-GBV Command Centre ku-0800 428 428 noma amaphoyisa ku-10111 manje. Awuwedwa — usizo luyatholakala.";
    } else {
      // Afrikaans fallback
      textToSay = "Welkom. Hierdie webwerf is 'n veilige plek om te deel as jy of iemand wat jy ken geslagsgebaseerde geweld ervaar het. Jou antwoorde is anoniem en beskerm. Indien jy in onmiddellike gevaar is, skakel die GBV-bevelsentrum by 0800 428 428 of die polisie by 10111. Jy is nie alleen nie — hulp is beskikbaar.";
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: { parts: [{ text: textToSay }] },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    // The audio data is returned in the inlineData of the first part
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
  } catch (error) {
    console.error("Error generating audio:", error);
    return null;
  }
};

// 2. Chat Logic for AIChat.tsx
export const getChatResponse = async (history: any[], newMessage: string): Promise<string> => {
  try {
    // History array structure expected: { role: 'user' | 'model', parts: [{ text: string }] }[]
    const contents = [
      ...history,
      { role: 'user', parts: [{ text: newMessage }] }
    ];

    const systemPrompt = `
    You are an empathetic, trauma-informed assistant designed to provide immediate emotional support and practical information for people affected by gender-based violence in South Africa.
    
    KNOWLEDGE BASE (CGE GBV Index 2024 & CSVR 2016):
    - **Scope**: GBV includes Physical, Sexual, Psychological (Emotional), and Economic violence.
    - **New Definitions (Domestic Violence Amendment Act 2021)**:
      - *Spiritual Abuse*: Preventing religious practice, using faith to justify abuse, or ridiculing beliefs.
      - *Coercive/Controlling Behaviour*: Patterns of intimidation, isolation, or control over daily life.
      - *Technology-facilitated GBV*: Online harassment, cyberstalking, revenge porn.
    - **Economic Impact**: GBV costs South Africa between R28.4 billion and R42.4 billion annually (0.9% - 1.3% of GDP).
    - **The "Iceberg" of Reporting**: Police stats are only the tip. Most incidents are unreported due to shame, stigma, and lack of trust.
    - **Legal Rights**: The Domestic Violence Act (116 of 1998) mandates police MUST assist victims and arrest perpetrators. Victims can apply for a Protection Order at a Magistrate's Court.
    - **Root Causes**: Patriarchal norms, inequality, alcohol misuse, and misuse of culture (e.g., *Lobola* being used to claim "ownership" of a wife, *Ukuthwala* abduction).
    
    - **Emergency Resources**:
      - GBV Command Centre: 0800 428 428 (*120*7867#)
      - SAPS Crime Stop: 08600 10111
      - TEARS Foundation: *134*7355# (Free USSD)
      - Childline: 116 / 0800 055 555
      - Thuthuzela Care Centres (TCC): Medical/legal help for rape survivors.

    PROTOCOL:
    1. **Safety First**: Always ask "Are you safe right now?" if the context is unclear.
    2. **Validate**: "I hear you," "It is not your fault." Validate spiritual and economic abuse as real violence.
    3. **Escalate High Risk**: If suicide, weapons, or immediate danger is mentioned, urge calling 10111 or 0800 428 428 immediately.
    4. **No Legal Advice**: Provide information on rights (e.g., "You have the right to a protection order"), but refer to Legal Aid or court clerks for advice.
    5. **Concise & Calm**: Keep answers short (max 200 words), clear, and supportive.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    return response.text || "I am currently unable to generate a response. Please contact the GBV Command Centre at 0800 428 428 if you need help.";
  } catch (error) {
    console.error("Chat Error:", error);
    return "I am currently offline. Please call 0800 428 428 for support.";
  }
};

// 3. Narrative Anonymization for SurveyForm.tsx
export const anonymizeStory = async (narrative: string, location: string): Promise<{ anonymized_narrative: string, risk_flag: 'low' | 'high' | 'medium' }> => {
  try {
    const prompt = `
      You are a privacy protection AI. 
      Task 1: Rewrite the following story to remove ALL personal identifiers (names, specific addresses, workplaces, phone numbers). Keep the emotional context and type of incident intact.
      Task 2: Assess the risk level based on the story.
         - 'high': Immediate threat to life, weapon involved now, suicidal intent, or ongoing attack.
         - 'medium': Serious past incident, ongoing harassment, coercive control, or severe distress.
         - 'low': Past incident, general reporting.
      
      User Location Context: ${location}
      Story: "${narrative}"
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            anonymized_narrative: { type: Type.STRING },
            risk_flag: { type: Type.STRING, enum: ["low", "medium", "high"] }
          },
          required: ["anonymized_narrative", "risk_flag"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      anonymized_narrative: result.anonymized_narrative || "Narrative redacted for privacy.",
      risk_flag: result.risk_flag || "low"
    };

  } catch (error) {
    console.error("Anonymization Error:", error);
    return {
      anonymized_narrative: "Error processing narrative. Submitting without narrative for safety.",
      risk_flag: "low"
    };
  }
};
