
import { SurveyData, PerpetratorData } from '../types';

const STORAGE_KEY = 'gbv_app_submissions';
const PERP_STORAGE_KEY = 'gbv_perp_submissions';
const HAS_SEEDED_KEY = 'gbv_app_has_seeded_v2';

// --- Survivor Storage ---
export const saveSubmission = (data: Partial<SurveyData>) => {
  try {
    const existing = getSubmissions();
    const updated = [...existing, data];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new Event('storage'));
  } catch (error) {
    console.error("Failed to save submission", error);
  }
};

export const getSubmissions = (): Partial<SurveyData>[] => {
  try {
    const str = localStorage.getItem(STORAGE_KEY);
    return str ? JSON.parse(str) : [];
  } catch (error) {
    console.error("Failed to load submissions", error);
    return [];
  }
};

// --- Perpetrator Storage ---
export const savePerpetratorSubmission = (data: Partial<PerpetratorData>) => {
  try {
    const existing = getPerpetratorSubmissions();
    const updated = [...existing, data];
    localStorage.setItem(PERP_STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new Event('storage'));
  } catch (error) {
    console.error("Failed to save perpetrator submission", error);
  }
};

export const getPerpetratorSubmissions = (): Partial<PerpetratorData>[] => {
  try {
    const str = localStorage.getItem(PERP_STORAGE_KEY);
    return str ? JSON.parse(str) : [];
  } catch (error) {
    console.error("Failed to load perp submissions", error);
    return [];
  }
};

export const clearSubmissions = () => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(PERP_STORAGE_KEY);
    localStorage.removeItem(HAS_SEEDED_KEY);
    window.dispatchEvent(new Event('storage'));
};

// --- Data Seeding ---
export const seedInitialData = () => {
    if (localStorage.getItem(HAS_SEEDED_KEY)) return;

    // Seed Survivor Data
    const MOCK_DATA: Partial<SurveyData>[] = [];
    const PROVINCES = ['Gauteng', 'KwaZulu-Natal', 'Western Cape', 'Eastern Cape', 'Limpopo', 'Mpumalanga', 'North West', 'Free State', 'Northern Cape'];
    const GENDERS = ['Female', 'Female', 'Female', 'Female', 'Male', 'Non-binary']; 
    const ABUSES = ['Physical assault', 'Sexual assault/rape', 'Emotional/Psych', 'Economic abuse', 'Coercive control', 'Tech-facilitated'];
    
    for (let i = 0; i < 65; i++) {
        const prov = PROVINCES[Math.floor(Math.random() * (i < 40 ? 4 : 9))];
        const gender = GENDERS[Math.floor(Math.random() * GENDERS.length)];
        const abuseCount = Math.ceil(Math.random() * 3);
        const types = Array.from({length: abuseCount}, () => ABUSES[Math.floor(Math.random() * ABUSES.length)]);
        const reported = Math.random() > 0.6 ? 'Yes' : (Math.random() > 0.5 ? 'Tried but blocked' : 'No');
        
        MOCK_DATA.push({
            submission_id: `mock-${Math.random().toString(36).substr(2,9)}`,
            province: prov,
            gender_identity: gender,
            age_range: ['18–24', '25–34', '35–44'][Math.floor(Math.random() * 3)],
            type_of_abuse: [...new Set(types)], 
            did_you_report: reported,
            perpetrator_relationship: ['Intimate partner', 'Ex-Partner', 'Family member', 'Stranger'][Math.floor(Math.random() * 4)],
            immediate_needs: ['Counselling', 'Safety', 'Legal help'].slice(0, Math.ceil(Math.random() * 2)),
            barriers_to_reporting: reported === 'No' ? ['Fear of reprisal', 'No Trust in Police', 'Shame'].slice(0, 2) : [],
            disability_status: Math.random() > 0.85 ? 'Yes (Physical)' : 'No',
            date_of_submission: new Date(Date.now() - Math.floor(Math.random() * 10000000000)).toISOString()
        });
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(MOCK_DATA));

    // Seed Perpetrator Data
    const PERP_MOCK: Partial<PerpetratorData>[] = [];
    const TRIGGERS = ['Alcohol or drug use', 'Jealousy', 'Anger issues', 'Financial stress'];
    const BEHAVIOURS = ['Physical harm', 'Emotional or verbal abuse', 'Financial control', 'Digital abuse'];
    
    for (let i = 0; i < 35; i++) {
        PERP_MOCK.push({
            submission_id: `perp-${Math.random()}`,
            province: PROVINCES[Math.floor(Math.random() * PROVINCES.length)],
            gender_identity: Math.random() > 0.8 ? 'Female' : 'Male',
            do_you_believe_you_have_caused_gbv: Math.random() > 0.3 ? 'Yes' : 'Maybe',
            type_of_behaviour_used: [BEHAVIOURS[Math.floor(Math.random() * BEHAVIOURS.length)]],
            triggers: [TRIGGERS[Math.floor(Math.random() * TRIGGERS.length)]],
            regret_actions: Math.random() > 0.4 ? 'Yes somewhat' : (Math.random() > 0.5 ? 'Yes deeply' : 'Not sure'),
            willing_to_change: Math.random() > 0.2 ? 'Yes' : 'Maybe',
            relationship_to_person: 'Partner'
        });
    }
    localStorage.setItem(PERP_STORAGE_KEY, JSON.stringify(PERP_MOCK));

    localStorage.setItem(HAS_SEEDED_KEY, 'true');
    window.dispatchEvent(new Event('storage'));
};

export const getLiveStats = () => {
    const submissions = getSubmissions();
    const perpSubmissions = getPerpetratorSubmissions();
    const total = submissions.length;

    // --- Survivor Aggregations ---
    const provinceCounts: Record<string, number> = {};
    submissions.forEach(s => {
        if (s.province) {
            const p = s.province.split(' ')[0]; 
            provinceCounts[p] = (provinceCounts[p] || 0) + 1;
        }
    });
    const provinceData = Object.keys(provinceCounts).map(key => ({ name: key, value: provinceCounts[key] }));

    const abuseCounts: Record<string, number> = {};
    submissions.forEach(s => {
        s.type_of_abuse?.forEach(type => {
            let label = type;
            if (type.includes("Physical")) label = "Physical";
            if (type.includes("Sexual")) label = "Sexual";
            if (type.includes("Emotional")) label = "Emotional";
            if (type.includes("Economic")) label = "Economic";
            if (type.includes("Tech")) label = "Cyber/Tech";
            if (type.includes("Spiritual")) label = "Spiritual";
            abuseCounts[label] = (abuseCounts[label] || 0) + 1;
        });
    });
    const abuseData = Object.keys(abuseCounts).map(key => ({ name: key, value: abuseCounts[key] }));

    const genderAbuseMap: Record<string, { Male: number, Female: number, Other: number }> = {};
    const initialCategories = ["Physical", "Sexual", "Emotional", "Economic", "Cyber/Tech", "Spiritual"];
    initialCategories.forEach(c => genderAbuseMap[c] = { Male: 0, Female: 0, Other: 0 });

    submissions.forEach(s => {
        let genderKey: 'Male' | 'Female' | 'Other' = 'Other';
        if (s.gender_identity === 'Male' || s.gender_identity === 'Transgender man') genderKey = 'Male';
        else if (s.gender_identity === 'Female' || s.gender_identity === 'Transgender woman') genderKey = 'Female';

        s.type_of_abuse?.forEach(type => {
            let label = 'Other';
            if (type.includes("Physical")) label = "Physical";
            else if (type.includes("Sexual")) label = "Sexual";
            else if (type.includes("Emotional")) label = "Emotional";
            else if (type.includes("Economic")) label = "Economic";
            else if (type.includes("Tech")) label = "Cyber/Tech";
            else if (type.includes("Spiritual")) label = "Spiritual";

            if (!genderAbuseMap[label]) genderAbuseMap[label] = { Male: 0, Female: 0, Other: 0 };
            genderAbuseMap[label][genderKey]++;
        });
    });

    const genderComparisonData = Object.keys(genderAbuseMap).map(key => ({
        name: key,
        Male: genderAbuseMap[key].Male,
        Female: genderAbuseMap[key].Female,
        Other: genderAbuseMap[key].Other
    }));

    const reportingByGender = { Male: { reported: 0, total: 0 }, Female: { reported: 0, total: 0 } };
    submissions.forEach(s => {
        let g: 'Male' | 'Female' | null = null;
        if (s.gender_identity === 'Male') g = 'Male';
        if (s.gender_identity === 'Female') g = 'Female';
        if (g) {
            reportingByGender[g].total++;
            if (s.did_you_report === 'Yes') reportingByGender[g].reported++;
        }
    });

    const ageCounts: Record<string, number> = {};
    submissions.forEach(s => {
        const age = s.age_range || 'Unknown';
        ageCounts[age] = (ageCounts[age] || 0) + 1;
    });
    const ageData = Object.keys(ageCounts).map(key => ({ name: key, value: ageCounts[key] }));

    let reported = 0, notReported = 0, blocked = 0;
    submissions.forEach(s => {
        if (s.did_you_report === 'Yes') reported++;
        else if (s.did_you_report === 'No') notReported++;
        else if (s.did_you_report?.includes('Tried')) blocked++;
        else notReported++;
    });
    const reportingStats = [
        { name: 'Reported', value: reported, fill: '#10b981' },
        { name: 'Silent/Unreported', value: notReported, fill: '#64748b' },
        { name: 'Blocked/Failed', value: blocked, fill: '#ef4444' },
    ];

    const genderCounts: Record<string, number> = {};
    submissions.forEach(s => {
        const g = s.gender_identity || 'Unknown';
        genderCounts[g] = (genderCounts[g] || 0) + 1;
    });
    const genderStats = Object.keys(genderCounts).map(key => ({ name: key, value: genderCounts[key] }));

    const needsCounts: Record<string, number> = {};
    submissions.forEach(s => {
        s.immediate_needs?.forEach(need => { needsCounts[need] = (needsCounts[need] || 0) + 1; });
    });
    const needsStats = Object.keys(needsCounts).map(key => ({ name: key, value: needsCounts[key] })).sort((a, b) => b.value - a.value).slice(0, 5);

    const relCounts: Record<string, number> = {};
    submissions.forEach(s => {
        const r = s.perpetrator_relationship || 'Unknown';
        relCounts[r] = (relCounts[r] || 0) + 1;
    });
    const relationshipData = Object.keys(relCounts).map(key => ({ name: key, value: relCounts[key] }));

    const barrierCounts: Record<string, number> = {};
    submissions.forEach(s => {
        s.barriers_to_reporting?.forEach(b => {
            let label = b;
            if(label.includes('Other')) label = 'Other';
            barrierCounts[label] = (barrierCounts[label] || 0) + 1;
        });
    });
    const barriersData = Object.keys(barrierCounts).map(key => ({ name: key, size: barrierCounts[key] }));

    const disCounts: Record<string, number> = {};
    submissions.forEach(s => {
        let d = s.disability_status || 'Unknown';
        if(d.includes('Yes')) d = 'With Disability';
        if(d === 'No') d = 'No Disability';
        disCounts[d] = (disCounts[d] || 0) + 1;
    });
    const disabilityData = Object.keys(disCounts).map(key => ({ name: key, value: disCounts[key] }));

    // --- Perpetrator Aggregations ---
    const triggerCounts: Record<string, number> = {};
    const regretCounts: Record<string, number> = {};
    const willingCounts: Record<string, number> = {};
    
    perpSubmissions.forEach(p => {
        p.triggers?.forEach(t => triggerCounts[t] = (triggerCounts[t] || 0) + 1);
        if (p.regret_actions) regretCounts[p.regret_actions] = (regretCounts[p.regret_actions] || 0) + 1;
        if (p.willing_to_change) willingCounts[p.willing_to_change] = (willingCounts[p.willing_to_change] || 0) + 1;
    });

    const triggerData = Object.keys(triggerCounts).map(k => ({ name: k, value: triggerCounts[k] }));
    const regretData = Object.keys(regretCounts).map(k => ({ name: k, value: regretCounts[k] }));
    const willingData = Object.keys(willingCounts).map(k => ({ name: k, value: willingCounts[k] }));

    return { 
        total, 
        perpTotal: perpSubmissions.length,
        provinceData, 
        abuseData, 
        genderComparisonData, 
        reportingByGender,    
        ageData,              
        reportingStats, 
        genderStats, 
        needsStats,
        relationshipData, 
        barriersData,     
        disabilityData,
        // Perp stats
        triggerData,
        regretData,
        willingData
    };
};
