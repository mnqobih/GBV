
export interface SurveyData {
  // A. Basic Info
  submission_id?: string;
  date_of_submission?: string;
  province: string;
  city_or_town: string;
  age_range: string;
  gender_identity: string;
  sexual_orientation: string;
  
  // New Demographic Context (HSRC/CGE)
  disability_status: string;
  employment_status: string;
  living_arrangement: string;

  // B. Incident Details
  have_you_experienced_gbv: string; // "Yes" | "No"
  observed_incident?: string; // If No to above
  type_of_abuse: string[];
  approx_date_of_incident: string;
  how_many_times: string;
  perpetrator_relationship: string;
  perpetrator_gender: string;
  same_gender_incident: string;
  age_of_perpetrator_range?: string;

  // C. Reporting & Response
  did_you_report: string;
  reported_to?: string;
  time_between_incident_and_report_days?: string;
  outcome_of_report?: string;
  did_you_access_medical_or_counselling_services: string;
  service_type?: string;

  // D. Impact & Needs
  physical_injury: string;
  ongoing_safety_concern: string;
  immediate_needs: string[];
  barriers_to_reporting: string[];
  would_you_like_follow_up: string;

  // E. Qualitative
  short_narrative?: string;
  consent_to_share_anonymized_data: string; // "Yes" | "No"
  
  // F. Metadata (Internal)
  ip_hash?: string;
  device_language?: string;
}

export interface PerpetratorData {
  submission_id: string;
  date_of_submission: string;
  
  // A. About You
  gender_identity: string;
  age_range: string;
  province: string;
  city_or_town: string;
  relationship_status: string;

  // B. Self-Reflection
  do_you_believe_you_have_caused_gbv: string; // Yes/Maybe/No
  type_of_behaviour_used: string[];
  victim_gender: string;
  relationship_to_person: string;

  // C. Context
  triggers: string[];
  first_time_or_pattern: string;
  feelings_during_incident: string[];

  // D. Awareness
  realised_it_was_gbv: string;
  tried_to_fix_it: string;
  take_responsibility: string;

  // E. Regret
  regret_actions: string;
  impact_on_other: string;
  impact_on_self: string;

  // F. Reporting
  did_person_report: string;
  consequences: string;
  received_help: string;
  support_needed: string[];

  // G. Change
  willing_to_change: string;
  steps_to_take: string[];
  use_app_for_help: string;

  // H. Optional
  final_message?: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}

export enum AppView {
  LANDING = 'LANDING',
  SURVEY = 'SURVEY',
  PERPETRATOR_SURVEY = 'PERPETRATOR_SURVEY',
  DASHBOARD = 'DASHBOARD',
  CHAT = 'CHAT',
}
