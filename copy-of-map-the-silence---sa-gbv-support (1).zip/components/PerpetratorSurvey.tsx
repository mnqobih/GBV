import React, { useState, useEffect } from 'react';
import { PerpetratorData } from '../types';
import { savePerpetratorSubmission } from '../services/storageService';

const generateUUID = () => Math.random().toString(36).substring(2) + Date.now().toString(36);

interface TileOptionProps {
  label: string;
  selected: boolean;
  onClick: () => void;
}

const TileOption: React.FC<TileOptionProps> = ({ label, selected, onClick }) => (
  <button
    onClick={onClick}
    className={`relative flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all w-full min-h-[60px] text-sm font-medium
      ${selected ? 'border-slate-800 bg-slate-100 text-slate-900 shadow-sm' : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'}`}
  >
    {label}
  </button>
);

export const PerpetratorSurvey: React.FC<{ onComplete: () => void, onExit: () => void }> = ({ onComplete, onExit }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<PerpetratorData>>({
    submission_id: generateUUID(),
    date_of_submission: new Date().toISOString(),
    type_of_behaviour_used: [],
    triggers: [],
    feelings_during_incident: [],
    support_needed: [],
    steps_to_take: []
  });

  useEffect(() => window.scrollTo(0,0), [step]);

  const update = (key: keyof PerpetratorData, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const toggle = (key: keyof PerpetratorData, value: string) => {
    const list = (formData[key] as string[]) || [];
    if (list.includes(value)) update(key, list.filter(i => i !== value));
    else update(key, [...list, value]);
  };

  const handleSubmit = () => {
    savePerpetratorSubmission(formData);
    onComplete();
  };

  // Disclaimer Banner
  const Disclaimer = () => (
    <div className="bg-amber-50 border-l-4 border-amber-500 p-4 mb-6 rounded-r-lg">
      <p className="text-sm text-amber-900">
        <strong>Note:</strong> This survey is for self-reflection and data collection. It does not excuse abusive behaviour. 
        If you have harmed someone, we strongly encourage seeking help. Real change begins with responsibility.
      </p>
    </div>
  );

  return (
    <div className="max-w-xl mx-auto pb-20">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mx-4 mt-4">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-slate-900">Self-Reflection</h2>
            <span className="text-xs font-bold bg-slate-100 px-2 py-1 rounded text-slate-500">Step {step}/8</span>
        </div>
        
        <Disclaimer />

        {/* STEP 1: ABOUT YOU */}
        {step === 1 && (
          <div className="space-y-6">
            <h3 className="font-semibold text-slate-700">Section A: About You (Anonymous)</h3>
            <div className="space-y-4">
                <label className="block text-xs font-bold uppercase text-slate-500">Gender Identity</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Male', 'Female', 'Non-binary', 'Prefer not to say'].map(o => (
                        <TileOption key={o} label={o} selected={formData.gender_identity === o} onClick={() => update('gender_identity', o)} />
                    ))}
                </div>
            </div>
            <div className="space-y-4">
                <label className="block text-xs font-bold uppercase text-slate-500">Relationship Status During Incident</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Single', 'Dating', 'Married', 'Living together', 'Separated'].map(o => (
                        <TileOption key={o} label={o} selected={formData.relationship_status === o} onClick={() => update('relationship_status', o)} />
                    ))}
                </div>
            </div>
            <div className="space-y-4">
                <label className="block text-xs font-bold uppercase text-slate-500">Province</label>
                <select className="w-full p-3 border rounded-lg" onChange={e => update('province', e.target.value)}>
                    <option value="">Select...</option>
                    {['Gauteng', 'KZN', 'Western Cape', 'Eastern Cape', 'Limpopo', 'Mpumalanga', 'North West', 'Free State', 'Northern Cape'].map(p => <option key={p} value={p}>{p}</option>)}
                </select>
            </div>
          </div>
        )}

        {/* STEP 2: SELF REFLECTION */}
        {step === 2 && (
          <div className="space-y-6">
            <h3 className="font-semibold text-slate-700">Section B: Have You Used GBV?</h3>
            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-800">Do you believe you have caused harm or used abusive behaviour?</label>
                <div className="grid grid-cols-3 gap-3">
                    {['Yes', 'Maybe', 'No'].map(o => (
                        <TileOption key={o} label={o} selected={formData.do_you_believe_you_have_caused_gbv === o} onClick={() => update('do_you_believe_you_have_caused_gbv', o)} />
                    ))}
                </div>
            </div>
            
            {formData.do_you_believe_you_have_caused_gbv === 'No' && (
                <div className="p-4 bg-slate-50 text-center rounded-lg mt-4">
                    <p className="text-sm text-slate-600 mb-4">Thank you. This survey ends here.</p>
                    <button onClick={onExit} className="text-brand-600 font-bold text-sm">Exit Survey</button>
                </div>
            )}

            {(formData.do_you_believe_you_have_caused_gbv === 'Yes' || formData.do_you_believe_you_have_caused_gbv === 'Maybe') && (
                <div className="space-y-4 animate-fade-in">
                    <label className="block text-xs font-bold uppercase text-slate-500">Behaviours Used (Multi-select)</label>
                    <div className="grid grid-cols-1 gap-2">
                        {['Physical harm', 'Sexual coercion', 'Emotional abuse', 'Psychological control', 'Financial control', 'Digital abuse', 'Stalking'].map(b => (
                            <button key={b} onClick={() => toggle('type_of_behaviour_used', b)} className={`p-3 text-sm rounded-lg border text-left ${formData.type_of_behaviour_used?.includes(b) ? 'bg-slate-800 text-white' : 'bg-white'}`}>{b}</button>
                        ))}
                    </div>
                    <div className="pt-4">
                        <label className="block text-xs font-bold uppercase text-slate-500">Relationship to Person</label>
                        <select className="w-full p-3 border rounded-lg mt-1" onChange={e => update('relationship_to_person', e.target.value)}>
                            <option value="">Select...</option>
                            {['Partner', 'Ex-partner', 'Family member', 'Friend', 'Stranger'].map(r => <option key={r} value={r}>{r}</option>)}
                        </select>
                    </div>
                </div>
            )}
          </div>
        )}

        {/* STEP 3: CONTEXT */}
        {step === 3 && (
          <div className="space-y-6">
            <h3 className="font-semibold text-slate-700">Section C: Context & Triggers</h3>
            <div className="space-y-4">
                <label className="block text-xs font-bold uppercase text-slate-500">What triggered the behaviour?</label>
                <div className="flex flex-wrap gap-2">
                    {['Jealousy', 'Alcohol or drug use', 'Argument', 'Financial stress', 'Feeling disrespected', 'Anger issues'].map(t => (
                        <button key={t} onClick={() => toggle('triggers', t)} className={`px-3 py-2 text-xs rounded-full border ${formData.triggers?.includes(t) ? 'bg-slate-800 text-white' : 'bg-white'}`}>{t}</button>
                    ))}
                </div>
            </div>
            <div className="space-y-4">
                <label className="block text-xs font-bold uppercase text-slate-500">Was this a pattern?</label>
                <div className="grid grid-cols-1 gap-2">
                    {['First time', 'Happened a few times', 'Regular pattern'].map(o => (
                        <TileOption key={o} label={o} selected={formData.first_time_or_pattern === o} onClick={() => update('first_time_or_pattern', o)} />
                    ))}
                </div>
            </div>
          </div>
        )}

        {/* STEP 4: AWARENESS */}
        {step === 4 && (
          <div className="space-y-6">
            <h3 className="font-semibold text-slate-700">Section D: Awareness & Responsibility</h3>
            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-800">Did you realise it was GBV at the time?</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Yes', 'No', 'Only later', 'Not sure'].map(o => (
                        <TileOption key={o} label={o} selected={formData.realised_it_was_gbv === o} onClick={() => update('realised_it_was_gbv', o)} />
                    ))}
                </div>
            </div>
            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-800">Do you take responsibility now?</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Yes', 'No', 'Partially', 'Not sure'].map(o => (
                        <TileOption key={o} label={o} selected={formData.take_responsibility === o} onClick={() => update('take_responsibility', o)} />
                    ))}
                </div>
            </div>
          </div>
        )}

        {/* STEP 5: REGRET */}
        {step === 5 && (
          <div className="space-y-6">
            <h3 className="font-semibold text-slate-700">Section E: Regret & Reflection</h3>
            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-800">Do you regret your actions?</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Yes deeply', 'Yes somewhat', 'Not sure', 'Not really'].map(o => (
                        <TileOption key={o} label={o} selected={formData.regret_actions === o} onClick={() => update('regret_actions', o)} />
                    ))}
                </div>
            </div>
            <div className="space-y-4">
                <label className="block text-xs font-bold uppercase text-slate-500">How do you think it impacted them?</label>
                <textarea className="w-full p-3 border rounded-lg text-sm" rows={3} placeholder="Reflection..." onChange={e => update('impact_on_other', e.target.value)} />
            </div>
          </div>
        )}

        {/* STEP 6: CONSEQUENCES */}
        {step === 6 && (
          <div className="space-y-6">
            <h3 className="font-semibold text-slate-700">Section F: Consequences</h3>
            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-800">Did the person report you?</label>
                <div className="grid grid-cols-3 gap-3">
                    {['Yes', 'No', 'Not sure'].map(o => (
                        <TileOption key={o} label={o} selected={formData.did_person_report === o} onClick={() => update('did_person_report', o)} />
                    ))}
                </div>
            </div>
            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-800">Have you received help/counselling?</label>
                <div className="grid grid-cols-3 gap-3">
                    {['Yes', 'No', 'Thinking about it'].map(o => (
                        <TileOption key={o} label={o} selected={formData.received_help === o} onClick={() => update('received_help', o)} />
                    ))}
                </div>
            </div>
          </div>
        )}

        {/* STEP 7: CHANGE */}
        {step === 7 && (
          <div className="space-y-6">
            <h3 className="font-semibold text-slate-700">Section G: Willingness to Change</h3>
            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-800">Are you willing to change?</label>
                <div className="grid grid-cols-3 gap-3">
                    {['Yes', 'Maybe', 'No'].map(o => (
                        <TileOption key={o} label={o} selected={formData.willing_to_change === o} onClick={() => update('willing_to_change', o)} />
                    ))}
                </div>
            </div>
            <div className="space-y-4">
                <label className="block text-xs font-bold uppercase text-slate-500">What steps will you take?</label>
                <div className="flex flex-wrap gap-2">
                    {['Counselling', 'Support Group', 'Anger Management', 'Leaving toxic relationship', 'Substance abuse help'].map(s => (
                        <button key={s} onClick={() => toggle('steps_to_take', s)} className={`px-3 py-2 text-xs rounded-full border ${formData.steps_to_take?.includes(s) ? 'bg-green-600 text-white border-green-600' : 'bg-white'}`}>{s}</button>
                    ))}
                </div>
            </div>
          </div>
        )}

        {/* STEP 8: FINAL */}
        {step === 8 && (
          <div className="space-y-6 text-center">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">🤝</div>
            <h3 className="text-xl font-bold text-slate-900">Ready to Submit</h3>
            <p className="text-slate-600 text-sm mb-6">Your honest reflection contributes to understanding and preventing violence. Your data is anonymous.</p>
            <textarea className="w-full p-3 border rounded-lg text-sm mb-4" rows={3} placeholder="Anything else you want to share?" onChange={e => update('final_message', e.target.value)} />
            <button onClick={handleSubmit} className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold shadow-lg hover:bg-slate-800">Submit Reflection</button>
          </div>
        )}

        <div className="mt-8 pt-4 border-t flex justify-between">
            {step > 1 && <button onClick={() => setStep(s => s-1)} className="text-slate-400 text-sm">Back</button>}
            {step < 8 && formData.do_you_believe_you_have_caused_gbv !== 'No' && (
                <button onClick={() => setStep(s => s+1)} className="ml-auto bg-slate-100 text-slate-700 px-4 py-2 rounded-lg text-sm font-bold">Next</button>
            )}
        </div>
      </div>
    </div>
  );
};