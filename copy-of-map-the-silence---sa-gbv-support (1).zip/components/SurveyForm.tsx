
import React, { useState, useEffect } from 'react';
import { SurveyData } from '../types';
import { anonymizeStory } from '../services/geminiService';
import { saveSubmission } from '../services/storageService';

// --- Constants & Data ---

const PROVINCES = ['Eastern Cape', 'Free State', 'Gauteng', 'KwaZulu-Natal', 'Limpopo', 'Mpumalanga', 'Northern Cape', 'North West', 'Western Cape'];

// Expanded City Lists
const CITIES_BY_PROVINCE: { [key: string]: string[] } = {
  'Eastern Cape': ['Gqeberha (Port Elizabeth)', 'East London', 'Mthatha', 'Makhanda', 'Komani', 'Jeffreys Bay', 'Graaff-Reinet', 'Aliwal North', 'Bhisho'],
  'Free State': ['Bloemfontein', 'Welkom', 'Sasolburg', 'Kroonstad', 'Parys', 'Bethlehem', 'Phuthaditjhaba', 'Virginia'],
  'Gauteng': ['Johannesburg', 'Pretoria', 'Soweto', 'Centurion', 'Sandton', 'Midrand', 'Roodepoort', 'Kempton Park', 'Benoni', 'Vereeniging', 'Vanderbijlpark', 'Alexandra', 'Mamelodi'],
  'KwaZulu-Natal': ['Durban', 'Pietermaritzburg', 'Newcastle', 'Richards Bay', 'Umlazi', 'Empangeni', 'Margate', 'Port Shepstone', 'Ladysmith', 'KwaDukuza'],
  'Limpopo': ['Polokwane', 'Thohoyandou', 'Tzaneen', 'Mokopane', 'Phalaborwa', 'Bela-Bela', 'Musina', 'Louis Trichardt'],
  'Mpumalanga': ['Mbombela (Nelspruit)', 'Emalahleni (Witbank)', 'Secunda', 'Middelburg', 'Hazyview', 'Malelane', 'Piet Retief', 'Standerton'],
  'North West': ['Mahikeng', 'Rustenburg', 'Potchefstroom', 'Klerksdorp', 'Brits', 'Hartbeespoort', 'Lichtenburg', 'Vryburg'],
  'Northern Cape': ['Kimberley', 'Upington', 'Springbok', 'Kuruman', 'De Aar', 'Kathu', 'Colesberg'],
  'Western Cape': ['Cape Town', 'Stellenbosch', 'Paarl', 'George', 'Mossel Bay', 'Somerset West', 'Knysna', 'Hermanus', 'Oudtshoorn', 'Worcester', 'Beaufort West']
};

const generateUUID = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

// --- Modern UI Components ---

interface TileOptionProps {
  label: string;
  selected: boolean;
  onClick: () => void;
  icon?: string;
}

const TileOption: React.FC<TileOptionProps> = ({ label, selected, onClick, icon }) => (
  <button
    onClick={onClick}
    className={`
      relative flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all duration-200 w-full h-full min-h-[80px]
      ${selected 
        ? 'border-brand-500 bg-brand-50 text-brand-700 shadow-sm ring-1 ring-brand-200' 
        : 'border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:bg-slate-50'
      }
    `}
  >
    {selected && (
      <div className="absolute top-2 right-2 text-brand-500">
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>
      </div>
    )}
    {icon && <span className="text-2xl mb-2">{icon}</span>}
    <span className="font-semibold text-sm text-center leading-tight">{label}</span>
  </button>
);

interface Props {
  onComplete: () => void;
}

export const SurveyForm: React.FC<Props> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [showHighRiskModal, setShowHighRiskModal] = useState(false);
  const [otherInputs, setOtherInputs] = useState<{[key: string]: string}>({});

  const [formData, setFormData] = useState<Partial<SurveyData>>({
    submission_id: generateUUID(),
    date_of_submission: new Date().toISOString(),
    type_of_abuse: [],
    immediate_needs: [],
    barriers_to_reporting: [],
    ip_hash: Math.random().toString(36).substring(7),
    device_language: navigator.language
  });

  // Scroll to top on step change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [step]);

  const update = (key: keyof SurveyData, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  // Handle City Reset Logic
  useEffect(() => {
    // If province changes, check if city is still valid
    if (formData.province && CITIES_BY_PROVINCE[formData.province]) {
        const cities = CITIES_BY_PROVINCE[formData.province];
        // If current city is not in the new province list (and isn't a custom entry), clear it
        if (formData.city_or_town && !cities.includes(formData.city_or_town) && formData.city_or_town !== 'Other') {
             update('city_or_town', '');
        }
    }
  }, [formData.province]);

  const toggleArrayItem = (key: 'type_of_abuse' | 'immediate_needs' | 'barriers_to_reporting', value: string) => {
    const current = formData[key] || [];
    if (current.includes(value)) {
      update(key, current.filter(item => item !== value));
    } else {
      update(key, [...current, value]);
    }
  };

  const handleMultiOtherTextChange = (field: string, text: string) => {
    setOtherInputs(prev => ({ ...prev, [field]: text }));
  };

  const finalizeSubmission = () => {
      const finalData = { ...formData };
      
      // Merge Other fields
      ['type_of_abuse', 'immediate_needs', 'barriers_to_reporting'].forEach((field: any) => {
         if (finalData[field]?.includes('Other') && otherInputs[field]) {
             finalData[field] = finalData[field]?.map((item: string) => item === 'Other' ? `Other: ${otherInputs[field]}` : item);
         }
      });

      // Merge City Custom Input
      if (formData.city_or_town === 'Other' && otherInputs['city_or_town']) {
          finalData.city_or_town = otherInputs['city_or_town'];
      }

      return finalData;
  };

  const handleSubmit = async () => {
    setLoading(true);
    let risk = 'low';
    
    if (formData.short_narrative && formData.consent_to_share_anonymized_data === 'Yes') {
      try {
        const anonResult = await anonymizeStory(formData.short_narrative, formData.city_or_town || 'Unknown');
        if (anonResult.risk_flag === 'high') risk = 'high';
      } catch (e) { console.error(e); }
    }

    const finalPayload = finalizeSubmission();
    saveSubmission(finalPayload);

    setTimeout(() => {
      setLoading(false);
      if (risk === 'high') setShowHighRiskModal(true);
      else setSubmitted(true);
    }, 1500);
  };

  // -- RENDER STEPS --

  if (showHighRiskModal) return <HighRiskModal onDismiss={() => setSubmitted(true)} />;
  if (submitted) return <SuccessView id={formData.submission_id} onComplete={onComplete} />;

  const totalSteps = 6;

  return (
    <div className="max-w-xl mx-auto pb-20">
      {/* Progress */}
      <div className="mb-6 px-4 pt-4 sticky top-16 bg-slate-50 z-10 pb-2">
        <div className="flex justify-between text-xs font-medium text-slate-400 mb-2 uppercase tracking-wide">
            <span>Step {step} of {totalSteps}</span>
            <span>{Math.round((step / totalSteps) * 100)}% Complete</span>
        </div>
        <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
          <div className="h-full bg-brand-500 transition-all duration-500 ease-out" style={{ width: `${(step / totalSteps) * 100}%` }}></div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mx-4 animate-fade-in">
        
        {/* STEP 1: Identity */}
        {step === 1 && (
          <div className="space-y-8">
            <div>
                <h2 className="text-xl font-bold text-slate-900 mb-1">Basic Information</h2>
                <p className="text-slate-500 text-sm">Help us understand who is affected. Anonymous.</p>
            </div>

            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-700">Age Range</label>
                <div className="grid grid-cols-3 gap-3">
                    {['Under 18', '18–24', '25–34', '35–44', '45–54', '55+'].map(opt => (
                        <TileOption key={opt} label={opt} selected={formData.age_range === opt} onClick={() => update('age_range', opt)} />
                    ))}
                </div>
            </div>

            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-700">Gender Identity</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Female', 'Male', 'Non-binary', 'Transgender woman', 'Transgender man', 'Prefer not to say'].map(opt => (
                        <TileOption key={opt} label={opt} selected={formData.gender_identity === opt} onClick={() => update('gender_identity', opt)} />
                    ))}
                </div>
            </div>

            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-700">Sexual Orientation</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Straight', 'Gay', 'Lesbian', 'Bisexual', 'Queer', 'Prefer not to say'].map(opt => (
                        <TileOption key={opt} label={opt} selected={formData.sexual_orientation === opt} onClick={() => update('sexual_orientation', opt)} />
                    ))}
                </div>
            </div>
          </div>
        )}

        {/* STEP 2: Context (New Questions) */}
        {step === 2 && (
          <div className="space-y-8">
             <div>
                <h2 className="text-xl font-bold text-slate-900 mb-1">Personal Context</h2>
                <p className="text-slate-500 text-sm">Understanding your environment helps identify risk factors.</p>
            </div>

            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-700">Do you have a disability?</label>
                <p className="text-xs text-slate-400">This helps us track vulnerabilities highlighted by the HSRC.</p>
                <div className="grid grid-cols-2 gap-3">
                    {['No', 'Yes (Physical)', 'Yes (Intellectual)', 'Yes (Sensory)', 'Prefer not to say'].map(opt => (
                        <TileOption key={opt} label={opt} selected={formData.disability_status === opt} onClick={() => update('disability_status', opt)} />
                    ))}
                </div>
            </div>

            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-700">Employment Status</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Employed', 'Unemployed', 'Student', 'Self-Employed', 'Retired', 'Other'].map(opt => (
                        <TileOption key={opt} label={opt} selected={formData.employment_status === opt} onClick={() => update('employment_status', opt)} />
                    ))}
                </div>
            </div>

            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-700">Living Arrangement</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Alone', 'With Partner/Spouse', 'With Parents/Family', 'With Friends', 'Shelter/Temporary'].map(opt => (
                        <TileOption key={opt} label={opt} selected={formData.living_arrangement === opt} onClick={() => update('living_arrangement', opt)} />
                    ))}
                </div>
            </div>
          </div>
        )}

        {/* STEP 3: Location (Fixed City Logic) */}
        {step === 3 && (
          <div className="space-y-8">
             <div>
                <h2 className="text-xl font-bold text-slate-900 mb-1">Location</h2>
                <p className="text-slate-500 text-sm">Where did the incident happen?</p>
            </div>

            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-700">Province</label>
                <div className="relative">
                    <select 
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl appearance-none outline-none focus:ring-2 focus:ring-brand-500 text-lg font-medium text-slate-800"
                        value={formData.province}
                        onChange={(e) => update('province', e.target.value)}
                    >
                        <option value="">Select Province...</option>
                        {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                    <div className="absolute right-4 top-5 pointer-events-none text-slate-400">▼</div>
                </div>
            </div>

            <div className="space-y-4 transition-all duration-300">
                <label className="block text-sm font-bold text-slate-700">City or Town</label>
                {!formData.province ? (
                    <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-slate-400 text-sm">
                        Please select a province first
                    </div>
                ) : (
                    <div className="space-y-3">
                        <div className="relative">
                            <select 
                                className="w-full p-4 bg-white border border-slate-300 rounded-xl appearance-none outline-none focus:ring-2 focus:ring-brand-500 text-lg font-medium text-slate-800"
                                value={CITIES_BY_PROVINCE[formData.province]?.includes(formData.city_or_town) ? formData.city_or_town : (formData.city_or_town ? 'Other' : '')}
                                onChange={(e) => {
                                    const val = e.target.value;
                                    update('city_or_town', val);
                                    if (val !== 'Other') setOtherInputs(prev => ({...prev, city_or_town: ''}));
                                }}
                            >
                                <option value="">Select City...</option>
                                {CITIES_BY_PROVINCE[formData.province]?.map(c => <option key={c} value={c}>{c}</option>)}
                                <option value="Other">Other (Type my town)</option>
                            </select>
                            <div className="absolute right-4 top-5 pointer-events-none text-slate-400">▼</div>
                        </div>

                        {/* Custom City Input */}
                        {(formData.city_or_town === 'Other' || (formData.city_or_town && !CITIES_BY_PROVINCE[formData.province]?.includes(formData.city_or_town))) && (
                            <input 
                                type="text"
                                autoFocus
                                placeholder="Type the name of your town/city..."
                                className="w-full p-4 bg-brand-50 border border-brand-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 text-brand-900 placeholder-brand-300"
                                value={otherInputs['city_or_town'] || ''}
                                onChange={(e) => {
                                    const val = e.target.value;
                                    setOtherInputs(prev => ({...prev, city_or_town: val}));
                                }}
                            />
                        )}
                    </div>
                )}
            </div>
          </div>
        )}

        {/* STEP 4: Incident */}
        {step === 4 && (
          <div className="space-y-8">
             <div>
                <h2 className="text-xl font-bold text-slate-900 mb-1">The Incident</h2>
                <p className="text-slate-500 text-sm">Experience details.</p>
            </div>

            <div className="space-y-4">
                <label className="block text-sm font-bold text-slate-700">Have you experienced GBV?</label>
                <div className="grid grid-cols-2 gap-4">
                    <TileOption label="Yes" selected={formData.have_you_experienced_gbv === 'Yes'} onClick={() => update('have_you_experienced_gbv', 'Yes')} icon="🛑" />
                    <TileOption label="No" selected={formData.have_you_experienced_gbv === 'No'} onClick={() => update('have_you_experienced_gbv', 'No')} icon="🛡️" />
                </div>
            </div>

            {formData.have_you_experienced_gbv === 'No' ? (
                <div className="p-4 bg-slate-50 rounded-xl">
                    <label className="block text-sm font-bold text-slate-700 mb-3">Are you reporting as an observer?</label>
                    <div className="grid grid-cols-2 gap-3">
                        <TileOption label="Yes, I witnessed it" selected={formData.observed_incident === 'Yes'} onClick={() => update('observed_incident', 'Yes')} />
                        <TileOption label="No" selected={formData.observed_incident === 'No'} onClick={() => update('observed_incident', 'No')} />
                    </div>
                </div>
            ) : (
                <div className="space-y-4">
                    <label className="block text-sm font-bold text-slate-700">Type of Abuse (Select all that apply)</label>
                    <div className="grid grid-cols-2 gap-2">
                        {[
                            'Physical assault', 'Sexual assault/rape', 'Emotional/Psych', 
                            'Economic abuse', 'Stalking', 'Online abuse', 
                            'Coercive control', 'Spiritual abuse', 'Tech-facilitated'
                        ].map(type => (
                            <button
                                key={type}
                                onClick={() => toggleArrayItem('type_of_abuse', type)}
                                className={`p-3 text-xs font-semibold rounded-lg border transition-all ${
                                    formData.type_of_abuse?.includes(type) 
                                    ? 'bg-brand-600 text-white border-brand-600 shadow-md transform scale-105' 
                                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                                }`}
                            >
                                {type}
                            </button>
                        ))}
                    </div>
                    
                    <div className="pt-4">
                        <label className="block text-sm font-bold text-slate-700 mb-2">Relationship to Perpetrator</label>
                        <select 
                            className="w-full p-3 bg-white border border-slate-300 rounded-lg outline-none"
                            value={formData.perpetrator_relationship}
                            onChange={(e) => update('perpetrator_relationship', e.target.value)}
                        >
                            <option value="">Select Relationship...</option>
                            {['Intimate partner', 'Ex-partner', 'Family member', 'Friend', 'Colleague', 'Stranger', 'Authority figure'].map(r => (
                                <option key={r} value={r}>{r}</option>
                            ))}
                        </select>
                    </div>
                </div>
            )}
          </div>
        )}

        {/* STEP 5: Response & Impact (ENHANCED) */}
        {step === 5 && (
          <div className="space-y-8">
             <div>
                <h2 className="text-xl font-bold text-slate-900 mb-1">Aftermath & Needs</h2>
                <p className="text-slate-500 text-sm">Impact, reporting barriers, and requirements.</p>
            </div>

            {/* Physical Injury */}
            <div className="space-y-2">
                <label className="block text-sm font-bold text-slate-700">Did you sustain physical injury?</label>
                <div className="grid grid-cols-2 gap-3">
                    <TileOption label="Yes" selected={formData.physical_injury === 'Yes'} onClick={() => update('physical_injury', 'Yes')} />
                    <TileOption label="No" selected={formData.physical_injury === 'No'} onClick={() => update('physical_injury', 'No')} />
                </div>
            </div>

            {/* Ongoing Safety */}
            <div className="space-y-2">
                <label className="block text-sm font-bold text-slate-700">Do you have ongoing safety concerns?</label>
                <div className="grid grid-cols-2 gap-3">
                    <TileOption label="Yes" selected={formData.ongoing_safety_concern === 'Yes'} onClick={() => update('ongoing_safety_concern', 'Yes')} />
                    <TileOption label="No" selected={formData.ongoing_safety_concern === 'No'} onClick={() => update('ongoing_safety_concern', 'No')} />
                </div>
            </div>

            {/* Reporting */}
            <div className="space-y-2">
                <label className="block text-sm font-bold text-slate-700">Did you report this?</label>
                <div className="grid grid-cols-2 gap-3">
                    {['Yes', 'No', 'Tried but blocked', 'Prefer not to say'].map(opt => (
                        <TileOption key={opt} label={opt} selected={formData.did_you_report === opt} onClick={() => update('did_you_report', opt)} />
                    ))}
                </div>
            </div>

            {/* Barriers to Reporting */}
            <div className="space-y-2">
                <label className="block text-sm font-bold text-slate-700">If not reported, what were the barriers? (Optional)</label>
                <div className="flex flex-wrap gap-2">
                    {['Fear of reprisal', 'Stigma', 'No Trust in Police', 'Distance/Cost', 'Lack of proof', 'Other'].map(barrier => (
                        <button
                            key={barrier}
                            onClick={() => toggleArrayItem('barriers_to_reporting', barrier)}
                            className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors border ${
                                formData.barriers_to_reporting?.includes(barrier)
                                ? 'bg-slate-700 text-white border-slate-700'
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                            }`}
                        >
                            {barrier}
                        </button>
                    ))}
                </div>
            </div>

            {/* Immediate Needs */}
            <div className="space-y-2">
                <label className="block text-sm font-bold text-slate-700">What are your immediate needs?</label>
                <div className="flex flex-wrap gap-2">
                    {['Shelter', 'Medical care', 'Legal help', 'Counselling', 'Financial help', 'Safety', 'Child support'].map(need => (
                        <button
                            key={need}
                            onClick={() => toggleArrayItem('immediate_needs', need)}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                                formData.immediate_needs?.includes(need)
                                ? 'bg-teal-600 text-white shadow-sm'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                        >
                            {need}
                        </button>
                    ))}
                </div>
            </div>

            {/* Follow Up */}
            <div className="space-y-2">
                <label className="block text-sm font-bold text-slate-700">Would you like follow-up?</label>
                <p className="text-xs text-slate-400 mb-2">Only if you provide contact details (handled separately for privacy).</p>
                <div className="grid grid-cols-2 gap-3">
                    <TileOption label="Yes" selected={formData.would_you_like_follow_up === 'Yes'} onClick={() => update('would_you_like_follow_up', 'Yes')} />
                    <TileOption label="No" selected={formData.would_you_like_follow_up === 'No'} onClick={() => update('would_you_like_follow_up', 'No')} />
                </div>
            </div>
          </div>
        )}

        {/* STEP 6: Narrative */}
        {step === 6 && (
          <div className="space-y-6">
             <div>
                <h2 className="text-xl font-bold text-slate-900 mb-1">Your Voice (Optional)</h2>
                <p className="text-slate-500 text-sm">Share your story securely.</p>
            </div>

            <div className="bg-amber-50 p-4 rounded-lg border border-amber-100 text-amber-900 text-sm">
                🛡️ <strong>Privacy Guard:</strong> Our AI will automatically remove names, addresses, and phone numbers from your story before it is saved.
            </div>

            <textarea
                className="w-full h-40 p-4 border border-slate-300 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none resize-none text-sm leading-relaxed"
                placeholder="Type here..."
                value={formData.short_narrative || ''}
                onChange={(e) => update('short_narrative', e.target.value)}
            />

            <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-xl cursor-pointer" onClick={() => update('consent_to_share_anonymized_data', formData.consent_to_share_anonymized_data === 'Yes' ? 'No' : 'Yes')}>
                <div className={`w-6 h-6 rounded border flex items-center justify-center ${formData.consent_to_share_anonymized_data === 'Yes' ? 'bg-brand-600 border-brand-600' : 'bg-white border-slate-400'}`}>
                    {formData.consent_to_share_anonymized_data === 'Yes' && <span className="text-white text-xs">✓</span>}
                </div>
                <span className="text-sm text-slate-600 select-none">I consent to anonymized data sharing for research.</span>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="mt-10 pt-6 border-t border-slate-100 flex justify-between">
            <button 
                onClick={() => setStep(s => Math.max(1, s - 1))}
                disabled={step === 1}
                className="text-slate-500 font-medium px-4 py-2 hover:text-slate-800 disabled:opacity-30"
            >
                Back
            </button>
            
            <button 
                onClick={step === totalSteps ? handleSubmit : () => setStep(s => s + 1)}
                className="bg-brand-600 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-brand-200 hover:bg-brand-700 active:scale-95 transition-all flex items-center gap-2"
                disabled={loading || (step === totalSteps && formData.consent_to_share_anonymized_data !== 'Yes')}
            >
                {loading ? 'Submitting...' : (step === totalSteps ? 'Finish & Submit' : 'Continue')}
                {!loading && step !== totalSteps && <span>→</span>}
            </button>
        </div>

      </div>
    </div>
  );
};

// --- Sub-Components ---

const HighRiskModal = ({ onDismiss }: { onDismiss: () => void }) => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm animate-fade-in">
        <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">⚠️</div>
            <h3 className="text-xl font-bold text-red-700 mb-2">Immediate Safety Alert</h3>
            <p className="text-slate-600 mb-6 text-sm">Your report suggests high risk. Please prioritize your safety.</p>
            <div className="space-y-3">
                <a href="tel:10111" className="block w-full bg-red-600 text-white py-3 rounded-xl font-bold shadow-md">Call Police (10111)</a>
                <a href="tel:0800428428" className="block w-full bg-white border-2 border-slate-200 text-slate-700 py-3 rounded-xl font-bold">GBV Command Centre</a>
            </div>
            <button onClick={onDismiss} className="mt-6 text-slate-400 text-xs underline">I am safe, continue</button>
        </div>
    </div>
);

const SuccessView = ({ id, onComplete }: { id?: string, onComplete: () => void }) => (
    <div className="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-lg border border-brand-100 text-center mt-8 animate-fade-in">
        <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6 text-4xl shadow-sm">✓</div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Submission Received</h2>
        <p className="text-slate-500 mb-8">Your voice has been counted securely.</p>
        
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 mb-8">
            <p className="text-xs text-slate-400 uppercase tracking-wider font-bold mb-2">Reference ID</p>
            <code className="block font-mono text-lg text-slate-800 bg-white p-2 rounded border border-slate-200 select-all">{id}</code>
        </div>

        <button onClick={onComplete} className="w-full bg-brand-600 text-white py-4 rounded-xl font-bold shadow-lg shadow-brand-100 hover:bg-brand-700 transition-all">
            View Live Dashboard
        </button>
    </div>
);
