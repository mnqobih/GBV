
import React from 'react';

interface LogoProps {
  className?: string;
  showText?: boolean;
  lightMode?: boolean; // For dark backgrounds
}

export const Logo: React.FC<LogoProps> = ({ className = "w-10 h-10", showText = false, lightMode = false }) => {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      <svg viewBox="0 0 100 100" className="h-full w-auto overflow-visible" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="brandGradient" x1="0" y1="0" x2="100" y2="100">
            <stop offset="0%" stopColor="#0ea5e9" />
            <stop offset="100%" stopColor="#0284c7" />
          </linearGradient>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>
        
        {/* Outer Ring / Pin Shape Halo */}
        <path 
          d="M50 95C50 95 15 62 15 40C15 20.67 30.67 5 50 5C69.33 5 85 20.67 85 40C85 62 50 95 50 95Z" 
          fill="url(#brandGradient)" 
          className="drop-shadow-sm"
        />
        
        {/* Inner White Circle */}
        <circle cx="50" cy="40" r="28" fill="white" />

        {/* Sound Wave Bars (The 'Voice' inside the Map) */}
        {/* Bar 1 */}
        <rect x="32" y="35" width="6" height="10" rx="3" fill="#0284c7">
          <animate attributeName="height" values="10;20;10" dur="1.5s" repeatCount="indefinite" />
          <animate attributeName="y" values="35;30;35" dur="1.5s" repeatCount="indefinite" />
        </rect>
        {/* Bar 2 (Center - Taller) */}
        <rect x="42" y="28" width="6" height="24" rx="3" fill="#0369a1">
          <animate attributeName="height" values="24;34;24" dur="1.5s" begin="0.1s" repeatCount="indefinite" />
          <animate attributeName="y" values="28;23;28" dur="1.5s" begin="0.1s" repeatCount="indefinite" />
        </rect>
        {/* Bar 3 (Tallest) */}
        <rect x="52" y="25" width="6" height="30" rx="3" fill="#0c4a6e">
          <animate attributeName="height" values="30;15;30" dur="1.5s" begin="0.2s" repeatCount="indefinite" />
          <animate attributeName="y" values="25;32.5;25" dur="1.5s" begin="0.2s" repeatCount="indefinite" />
        </rect>
        {/* Bar 4 */}
        <rect x="62" y="32" width="6" height="16" rx="3" fill="#0284c7">
          <animate attributeName="height" values="16;26;16" dur="1.5s" begin="0.3s" repeatCount="indefinite" />
          <animate attributeName="y" values="32;27;32" dur="1.5s" begin="0.3s" repeatCount="indefinite" />
        </rect>

        {/* Pulse Effect Ring (optional visual flair) */}
        <circle cx="50" cy="40" r="40" stroke="white" strokeWidth="1" opacity="0.3">
           <animate attributeName="r" values="35;45;35" dur="3s" repeatCount="indefinite" />
           <animate attributeName="opacity" values="0.5;0;0.5" dur="3s" repeatCount="indefinite" />
        </circle>
      </svg>
      
      {showText && (
        <div className="flex flex-col leading-none">
          <span className={`font-extrabold tracking-tight text-xl ${lightMode ? 'text-white' : 'text-slate-900'}`}>
            Map the Silence
          </span>
          <span className={`text-[10px] font-bold tracking-widest uppercase ${lightMode ? 'text-brand-200' : 'text-brand-600'}`}>
            SA GBV Support
          </span>
        </div>
      )}
    </div>
  );
};
