
import React, { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Treemap
} from 'recharts';
import { getLiveStats } from '../services/storageService';

// Colors
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export const Dashboard: React.FC = () => {
  const [viewMode, setViewMode] = useState<'survivor' | 'perpetrator'>('survivor');
  const [liveStats, setLiveStats] = useState<any>(null);

  useEffect(() => {
      const load = () => setLiveStats(getLiveStats());
      load();
      window.addEventListener('storage', load);
      return () => window.removeEventListener('storage', load);
  }, []);

  if (!liveStats) return <div>Loading stats...</div>;

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-800 mb-4 md:mb-0">Analytics Dashboard</h2>
            
            {/* View Toggle */}
            <div className="flex bg-slate-100 p-1 rounded-lg">
                <button 
                    onClick={() => setViewMode('survivor')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${viewMode === 'survivor' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-500'}`}
                >
                    Survivor Insights
                </button>
                <button 
                    onClick={() => setViewMode('perpetrator')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${viewMode === 'perpetrator' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
                >
                    Perpetrator / Reflection
                </button>
            </div>
        </div>

        {viewMode === 'survivor' ? (
            <div className="space-y-8">
                {/* KPI Cards */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-brand-50 p-4 rounded-xl border border-brand-100">
                        <p className="text-xs uppercase text-brand-600 font-bold">Total Reports</p>
                        <p className="text-3xl font-bold text-brand-900">{liveStats.total}</p>
                    </div>
                    <div className="bg-red-50 p-4 rounded-xl border border-red-100">
                        <p className="text-xs uppercase text-red-600 font-bold">Unreported Gap</p>
                        <p className="text-3xl font-bold text-red-900">{liveStats.reportingStats[1]?.value || 0}</p>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-xl border border-purple-100">
                        <p className="text-xs uppercase text-purple-600 font-bold">Disabled Victims</p>
                        <p className="text-3xl font-bold text-purple-900">{liveStats.disabilityData.find((d:any) => d.name.includes('With'))?.value || 0}</p>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-xl border border-orange-100">
                        <p className="text-xs uppercase text-orange-600 font-bold">Top Need</p>
                        <p className="text-lg font-bold text-orange-900 truncate">{liveStats.needsStats[0]?.name || 'N/A'}</p>
                    </div>
                </div>

                {/* Charts Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="h-80 bg-slate-50 p-4 rounded-lg">
                        <h3 className="font-bold text-slate-700 mb-4">Incidents by Province</h3>
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={liveStats.provinceData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" tick={{fontSize: 10}} />
                                <YAxis />
                                <RechartsTooltip />
                                <Bar dataKey="value" fill="#0284c7" radius={[4,4,0,0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                    
                    <div className="h-80 bg-slate-50 p-4 rounded-lg">
                        <h3 className="font-bold text-slate-700 mb-4">Reporting Culture by Gender</h3>
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={[{name: 'Male', ...liveStats.reportingByGender.Male}, {name: 'Female', ...liveStats.reportingByGender.Female}]}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <RechartsTooltip />
                                <Legend />
                                <Bar dataKey="total" name="Total Victims" fill="#94a3b8" />
                                <Bar dataKey="reported" name="Reported to Police" fill="#10b981" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        ) : (
            <div className="space-y-8">
                <div className="bg-slate-900 text-white p-6 rounded-xl mb-6">
                    <h3 className="text-xl font-bold mb-2">Self-Reflection Data</h3>
                    <p className="text-slate-400 text-sm">
                        Based on {liveStats.perpTotal} anonymous submissions from individuals admitting to or questioning their own abusive behaviour. 
                        This data helps design better prevention and rehabilitation programs.
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Triggers Chart */}
                    <div className="h-80 bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <h3 className="font-bold text-slate-700 mb-4">Reported Triggers of Violence</h3>
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart layout="vertical" data={liveStats.triggerData} margin={{left: 40}}>
                                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                                <XAxis type="number" hide />
                                <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 11}} />
                                <RechartsTooltip />
                                <Bar dataKey="value" fill="#dc2626" radius={[0,4,4,0]} barSize={20} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>

                    {/* Regret Chart */}
                    <div className="h-80 bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <h3 className="font-bold text-slate-700 mb-4">Levels of Regret</h3>
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie data={liveStats.regretData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} dataKey="value" label>
                                    {liveStats.regretData.map((entry:any, index:number) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <RechartsTooltip />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>

                    {/* Willingness to Change */}
                    <div className="h-80 bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <h3 className="font-bold text-slate-700 mb-4">Willingness to Seek Help</h3>
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie data={liveStats.willingData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label>
                                    {liveStats.willingData.map((entry:any, index:number) => (
                                        <Cell key={`cell-${index}`} fill={index === 0 ? '#10b981' : '#64748b'} />
                                    ))}
                                </Pie>
                                <RechartsTooltip />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};
