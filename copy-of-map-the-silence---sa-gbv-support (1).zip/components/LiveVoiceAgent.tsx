
import React, { useEffect, useRef, useState } from 'react';
import { ai } from '../services/geminiService';
import { Modality, LiveServerMessage } from '@google/genai';

// --- Audio Utils ---
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Convert Float32 from AudioContext to PCM Int16
function floatTo16BitPCM(input: Float32Array) {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
        const s = Math.max(-1, Math.min(1, input[i]));
        output[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    return output;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
    // CRITICAL FIX: Use byteOffset and specific length to create the view correctly
    const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.length / 2);
    
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
        const channelData = buffer.getChannelData(channel);
        for (let i = 0; i < frameCount; i++) {
            channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
        }
    }
    return buffer;
}

// --- Component ---
export const LiveVoiceAgent: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [status, setStatus] = useState<'connecting' | 'connected' | 'error' | 'permission_denied'>('connecting');
    const [isMuted, setIsMuted] = useState(false);
    const [volume, setVolume] = useState(0); 

    // Refs for cleanup and closure access
    const audioContextRef = useRef<AudioContext | null>(null);
    const outputContextRef = useRef<AudioContext | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const processorRef = useRef<ScriptProcessorNode | null>(null);
    
    // Mute Ref to be accessible inside audio processor closure
    const isMutedRef = useRef(isMuted);

    // Playback state
    const nextStartTimeRef = useRef<number>(0);
    const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

    useEffect(() => {
        isMutedRef.current = isMuted;
    }, [isMuted]);

    useEffect(() => {
        let isActive = true;
        let session: any = null;

        const startSession = async () => {
            try {
                // 1. Setup Audio Contexts
                const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                
                if (outputCtx.state === 'suspended') {
                    await outputCtx.resume();
                }

                audioContextRef.current = inputCtx;
                outputContextRef.current = outputCtx;

                // 2. Setup Mic Stream with Error Handling
                let stream;
                try {
                    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                } catch (err) {
                    console.error("Microphone permission denied:", err);
                    setStatus('permission_denied');
                    return;
                }
                streamRef.current = stream;

                // 3. Setup Processing Pipeline
                const source = inputCtx.createMediaStreamSource(stream);
                const processor = inputCtx.createScriptProcessor(4096, 1, 1);
                processorRef.current = processor;
                
                const analyser = inputCtx.createAnalyser();
                analyser.fftSize = 32;
                source.connect(analyser);

                source.connect(processor);
                processor.connect(inputCtx.destination);

                // 4. Connect to Gemini Live
                session = await ai.live.connect({
                    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                    callbacks: {
                        onopen: () => {
                            if (!isActive) return;
                            console.log("Live Session Connected");
                        },
                        onmessage: async (message: LiveServerMessage) => {
                            if (!isActive) return;
                            
                            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                            if (audioData && outputContextRef.current) {
                                const ctx = outputContextRef.current;
                                const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
                                
                                const src = ctx.createBufferSource();
                                src.buffer = buffer;
                                src.connect(ctx.destination);
                                
                                const now = ctx.currentTime;
                                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, now);
                                src.start(nextStartTimeRef.current);
                                nextStartTimeRef.current += buffer.duration;
                                
                                sourcesRef.current.add(src);
                                src.onended = () => sourcesRef.current.delete(src);
                            }

                            if (message.serverContent?.interrupted) {
                                sourcesRef.current.forEach(s => s.stop());
                                sourcesRef.current.clear();
                                nextStartTimeRef.current = 0;
                            }
                        },
                        onclose: () => console.log("Live Session Closed"),
                        onerror: (err) => {
                            console.error("Live Session Error", err);
                            setStatus('error');
                        }
                    },
                    config: {
                        responseModalities: [Modality.AUDIO],
                        speechConfig: {
                            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } }
                        },
                        systemInstruction: `You are Khanya, a compassionate South African GBV crisis support assistant.
                        
                        KNOWLEDGE BASE (CGE Index 2024):
                        - You know that GBV includes Physical, Sexual, Psychological, and Economic violence.
                        - You understand 'Spiritual Abuse' (using faith to harm) and 'Coercive Control' (isolation/intimidation) are forms of domestic violence.
                        - You are aware that women with disabilities face double the risk of sexual violence.
                        - You can refer to TEARS (*134*7355#), POWA (011 591 6803), and Thuthuzela Care Centres.
                        
                        IMPORTANT: 
                        1. You must initiate the conversation immediately. Do not wait for the user to speak. Start by saying 'Hello, I am Khanya. I am here to listen and support you safely.' then pause. 
                        2. If the user is in danger, calmly urge them to call 0800 428 428. 
                        3. Be concise but caring.`,
                    }
                });

                if (!isActive) {
                    session.close();
                    return;
                }

                setStatus('connected');

                // 6. Send Audio Data Loop
                processor.onaudioprocess = (e) => {
                    const inputData = e.inputBuffer.getChannelData(0);
                    
                    let sum = 0;
                    for(let i=0; i<inputData.length; i+=50) sum += Math.abs(inputData[i]);
                    const avg = sum / (inputData.length/50);
                    setVolume(Math.min(100, avg * 500)); 

                    if (isMutedRef.current) {
                        inputData.fill(0); 
                    }

                    const pcm16 = floatTo16BitPCM(inputData);
                    const pcmBlob = {
                        data: encode(new Uint8Array(pcm16.buffer)),
                        mimeType: 'audio/pcm;rate=16000'
                    };

                    session.sendRealtimeInput({ media: pcmBlob });
                };

            } catch (e) {
                console.error("Setup failed", e);
                setStatus('error');
            }
        };

        startSession();

        return () => {
            isActive = false;
            streamRef.current?.getTracks().forEach(t => t.stop());
            processorRef.current?.disconnect();
            audioContextRef.current?.close();
            outputContextRef.current?.close();
        };
    }, []);

    const visualizerScale = 1 + (volume / 100);

    return (
        <div className="fixed inset-0 z-[60] bg-slate-900 flex flex-col items-center justify-center text-white p-6 animate-fade-in">
            <div className="absolute top-6 left-6 right-6 flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full animate-pulse ${status === 'connected' ? 'bg-green-500' : (status === 'error' || status === 'permission_denied' ? 'bg-red-500' : 'bg-yellow-500')}`}></span>
                    <span className="text-sm font-medium text-slate-300">
                        {status === 'connected' ? 'Secure Line Active' : 
                         status === 'error' ? 'Connection Error' : 
                         status === 'permission_denied' ? 'Mic Access Denied' : 
                         'Connecting...'}
                    </span>
                </div>
                <button onClick={onClose} className="text-slate-400 hover:text-white">
                    Minimize
                </button>
            </div>

            <div className="flex-1 flex items-center justify-center relative w-full">
                <div 
                    className="absolute w-64 h-64 bg-brand-500/20 rounded-full blur-3xl transition-transform duration-75"
                    style={{ transform: `scale(${visualizerScale})` }}
                />
                
                <div className="relative z-10">
                    <div 
                        className={`w-32 h-32 rounded-full bg-gradient-to-br ${status === 'connected' ? 'from-brand-600 to-brand-400' : 'from-slate-700 to-slate-600'} shadow-[0_0_50px_rgba(14,165,233,0.4)] flex items-center justify-center transition-transform duration-75`}
                        style={{ transform: `scale(${Math.max(1, visualizerScale * 0.8)})` }}
                    >
                         <span className="text-4xl">🎙️</span>
                    </div>
                    {status === 'connecting' && (
                        <div className="absolute -bottom-12 left-0 right-0 text-center text-sm text-slate-400 animate-pulse">
                            Establishing secure connection...
                        </div>
                    )}
                     {status === 'error' && (
                        <div className="absolute -bottom-16 left-0 right-0 text-center text-sm text-red-400 font-bold">
                            Connection failed. <br/>Dial 0800 428 428.
                        </div>
                    )}
                    {status === 'permission_denied' && (
                        <div className="absolute -bottom-16 left-0 right-0 text-center text-sm text-red-400 font-bold">
                            Please allow microphone access.
                        </div>
                    )}
                </div>
            </div>

            <div className="mb-12 w-full max-w-sm grid grid-cols-3 gap-8">
                <button 
                    onClick={() => setIsMuted(!isMuted)}
                    className={`flex flex-col items-center gap-2 ${isMuted ? 'text-white' : 'text-slate-400 hover:text-white'}`}
                >
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center text-xl transition-colors ${isMuted ? 'bg-white text-slate-900' : 'bg-slate-800'}`}>
                        {isMuted ? '🔇' : '🎤'}
                    </div>
                    <span className="text-xs">{isMuted ? 'Unmute' : 'Mute'}</span>
                </button>

                <button 
                    onClick={onClose}
                    className="flex flex-col items-center gap-2 text-white"
                >
                    <div className="w-16 h-16 rounded-full bg-red-600 flex items-center justify-center text-2xl shadow-lg hover:bg-red-700 transition-transform hover:scale-105 active:scale-95">
                        📞
                    </div>
                    <span className="text-xs font-bold">End Call</span>
                </button>

                <button className="flex flex-col items-center gap-2 text-slate-400 hover:text-white opacity-50 cursor-not-allowed">
                    <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center text-xl">
                        ⌨️
                    </div>
                    <span className="text-xs">Keypad</span>
                </button>
            </div>
            
            <p className="text-xs text-slate-500 max-w-xs text-center">
                AI can make mistakes. For emergencies call 10111 immediately.
            </p>
        </div>
    );
};
